<nav class="page-breadcrumb d-flex align-items-center justify-content-between">
    <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{route('admin.departments.index')}}">Department section</a></li>
        <li class="breadcrumb-item active" aria-current="page">Department create</li>
    </ol>

    @yield('button')
</nav>
