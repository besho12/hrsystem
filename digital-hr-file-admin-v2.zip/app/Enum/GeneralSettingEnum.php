<?php

namespace App\Enum;

enum GeneralSettingEnum:string
{
    case CONFIGURATION = 'configuration';
    case NORMAL = 'normal';
}
