<?php

return [
    'server_key' => env('FIREBASE_SERVER_KEY', null),
];

